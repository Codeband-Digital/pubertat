# Переменные

window.apiurl - путь к api

window.basename - путь расположения проекта для react-router

window.mediaurl - путь расположения изображений
